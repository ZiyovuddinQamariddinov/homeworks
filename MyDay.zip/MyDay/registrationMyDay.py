from tkinter import *
import pickle
import os

def pass_not_reg():
    global pass_not_reg
    pass_not_reg = Toplevel(login_screen)
    pass_not_reg.title("Pass not reg")
    pass_not_reg.geometry("200x200")
    Label(pass_not_reg, text="Pass not reg", fg="purple").pack()
    Button(pass_not_reg, text="ok", bg="purple", fg="white", command=closebtn2).pack()

def login_success():
    global login1_scrn
    login1_scrn = Toplevel(login_screen)
    login1_scrn.title("MY DAY")
    login1_scrn.geometry("350x500")
    Label(login1_scrn, text="MY DAY", fg="purple").pack()

    frame_tasks = tkinter.Frame(root)
    frame_tasks.pack()

    listbox_tasks = tkinter.Listbox(frame_tasks, height=10, width=50)
    listbox_tasks.pack(side=tkinter.LEFT)

    scrollbar_tasks = tkinter.Scrollbar(frame_tasks)
    scrollbar_tasks.pack(side=tkinter.RIGHT, fill=tkinter.Y)

    listbox_tasks.config(yscrollcommand=scrollbar_tasks.set)
    scrollbar_tasks.config(command=listbox_tasks.yview)

    entry_task = tkinter.Entry(root, width=50)
    entry_task.pack()

    button_add_task = tkinter.Button(root, text="Добавить задачу", width=48, command=add_task)
    button_add_task.pack()

    button_delete_task = tkinter.Button(root, text="Удалить задачу", width=48, command=delete_task)
    button_delete_task.pack()

    button_load_tasks = tkinter.Button(root, text="Загрузить задачи", width=48, command=load_tasks)
    button_load_tasks.pack()
    button_save_tasks = tkinter.Button(root, text="Сохранить задачи", width=48, command=save_tasks)
    button_save_tasks.pack()
    root.mainloop()
def user_not_found():
    global user_not_found_scrn
    user_not_found_scrn = Toplevel(login_screen)
    user_not_found_scrn.title("User Not Found")
    user_not_found_scrn.geometry("200x200")
    Label(user_not_found_scrn, text="User Not found", fg="purple").pack()
    Button(user_not_found_scrn, text="ok", bg="purple", fg="white", command=closebtn).pack()
def closebtn():
    user_not_found_scrn.destroy()
def closebtn1():
    login1_scrn.destroy()
def closebtn2():
    pass_not_reg.destroy()
def login():
    global login_screen
    global name3
    global password3
    global nam
    global pas
    login_screen = Toplevel(main_screen)
    login_screen.title("Login Screen")
    login_screen.geometry("300x250")
    Label(login_screen, text="Добро пожаловать", height="2", width="300").pack()
    Label(text="").pack()
    Label(login_screen, text="Логин *").pack()


    name3 = StringVar()
    password3 = StringVar()
    nam = Entry(login_screen, textvariable=name3)
    nam.pack()
    Label(login_screen, text="Пароль *").pack()
    pas = Entry(login_screen, textvariable=password3, show='*')
    pas.pack()
    Button(login_screen, text="Вход", bg="purple", fg="white", command=login_user).pack()


def login_user():
    name = name3.get()
    passs = password3.get()
    nam.delete(0, END)
    pas.delete(0, END)
    list_of_dir = os.listdir()
    if name in list_of_dir:
        file1 = open(name, "r")
        verify = file1.read()
        if passs in verify:
            login_success()
        else:
            pass_not_reg()
    else:
        user_not_found()

def registration():
    global register_screen
    global name2
    global pass2
    register_screen = Toplevel(main_screen)
    register_screen.title("Регистрация")
    register_screen.geometry("300x250")
    Label(register_screen, text="Пройдите регистрацию", height="2", width="300").pack()
    Label(text="").pack()
    Label(register_screen, text="Придумайте Логин *").pack()
    global name
    global password
    name = StringVar()
    password = StringVar()
    name2 = Entry(register_screen, textvariable=name)
    name2.pack()
    Label(register_screen, text="Придумайте пароль *").pack()
    pass2 = Entry(register_screen, textvariable=password, show='*')
    pass2.pack()
    Button(register_screen, text="Регистрация", bg="purple", fg="white", command=register_user).pack()

def register_user():
    name1 = name.get()
    pass1 = password.get()
    file = open(name1, "w")
    file.write(name1 + "\n")
    file.write(pass1)
    file.close()
    name2.delete(0, END)
    pass2.delete(0, END)
    Label(register_screen, text="Вы успешна прошли регистрацию", fg="purple").pack()

def my_main_screen():
    global main_screen
    main_screen = Tk()
    main_screen.geometry("300x250")
    main_screen.title("MY DAY ")
    Label(text="My day you can DO IT", bg="purple", fg="white", height="2", width="300").pack()
    Label(text="").pack()
    Button(text="Login", height="2", width="29", bg="pink", fg="white", command=login).pack()
    Label(text="").pack()
    Button(text="Регистрация", height="2", width="30", bg="pink", fg="white", command=registration).pack()
    main_screen.mainloop()

my_main_screen()